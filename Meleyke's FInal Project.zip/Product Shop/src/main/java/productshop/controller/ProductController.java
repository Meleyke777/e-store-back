package productshop.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import productshop.dto.ProductDto;
import productshop.entity.Product;
// Removed Product entity import if not used elsewhere to keep it clean
import productshop.service.ProductService;
import productshop.service.UserProductService;

@CrossOrigin(
    origins = {
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:5501",
        "http://127.0.0.1:5501"
    },
    allowCredentials = "true"
)
@RestController
@RequestMapping("/api/v1/products")
public class ProductController {

    private final ProductService productService;
    private final UserProductService userProductService;

    public ProductController(ProductService productService,
                             UserProductService userProductService) {
        this.productService = productService;
        this.userProductService = userProductService;
    }

    @GetMapping
    public List<Product> getAll() {
        // FIXED: Changed return type from List<Product> to List<ProductDto>
        return productService.getAll(); 
    }

    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) {
        return productService.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProductDto create(@RequestBody ProductDto dto) {

        // Updated method name to be generic 'product'
        return userProductService.saveProduct(dto); 
    }

    @PutMapping("/{id}")
    public ProductDto update(@PathVariable Long id,
                             @Valid @RequestBody ProductDto dto) {
        // Updated method name to be generic 'product'
        return userProductService.updateProduct(id, dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        userProductService.deleteProduct(id);
    }

    @GetMapping("/my")
    public List<ProductDto> myProducts() {
        return userProductService.getMyProducts();
    }

    @GetMapping("/search")
    public List<Product> search(@RequestParam String keyword) {
        return productService.searchByBrand(keyword);
    }

    @GetMapping("/category/{category}")
    public List<Product> getByCategory(@PathVariable String category) {
        return productService.getByCategory(category);
    }

    @GetMapping("/rating/{rating}")
    public List<Product> getByRating(@PathVariable Integer rating) {
        return productService.getByRating(rating);
    }

    @GetMapping("/price/asc")
    public List<Product> priceAsc() {
        return productService.getPriceAsc();
    }

    @GetMapping("/price/desc")
    public List<Product> priceDesc() {
        return productService.getPriceDesc();
    }
}