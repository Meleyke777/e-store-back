package productshop.controller; // Renamed package to match style

import java.util.List;
import org.springframework.web.bind.annotation.*;
import productshop.dto.ReviewDto;
import productshop.entity.Review;
import productshop.repository.ReviewRepository;
import productshop.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;@CrossOrigin(
	    origins = "http://127.0.0.1:5500",
	    allowCredentials = "true"
	)
@RestController
@RequestMapping("/api/v1/reviews") // Added versioning for consistency
public class ReviewController {

	private ReviewService reviewService;

	// Use Constructor Injection instead of @Autowired on field
	public void Review(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Review create(@Valid @RequestBody ReviewDto reviewDto) {
		// Return the Review object, not the Controller
		return reviewService.create(reviewDto);
	}

	@GetMapping("/product/{productId}")
	public List<ReviewRepository> getByProduct(@PathVariable Long productId) {
		// Renamed from getByCloth to getByProduct
		return reviewService.getByProduct(productId);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id) {
		reviewService.delete(id);
	}
}