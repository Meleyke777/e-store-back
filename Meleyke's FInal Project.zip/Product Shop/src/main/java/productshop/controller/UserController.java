package productshop.controller;
	
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.security.core.userdetails.UsernameNotFoundException;
	import org.springframework.web.bind.annotation.*;
	import productshop.dto.RegisterRequestDto;
	import productshop.dto.LoginRequestDto;
	import productshop.entity.User;
	import productshop.jwt.JWTUtil;
	import productshop.repository.UserRepository;
	
	import java.security.Principal;
	import java.util.HashMap;
	import java.util.Map;
	import java.util.Optional;
	
	@RestController
	@RequestMapping("/api/v1/users")@CrossOrigin(
		    origins = "http://127.0.0.1:5500",
		    allowCredentials = "true"
		)
	public class UserController {
	
	    private final UserRepository userRepository;
	    private final JWTUtil jwtUtil;
	
	    public UserController(UserRepository userRepository, JWTUtil jwtUtil) {
	        this.userRepository = userRepository;
	        this.jwtUtil = jwtUtil;
	    }
	
	    // REGISTER → 201
	    @PostMapping("/register")
	    public ResponseEntity<?> register(@RequestBody RegisterRequestDto dto) {
	        // Check if username already exists
	        if (userRepository.findByUsername(dto.getUsername()).isPresent()) {
	            return ResponseEntity.status(HttpStatus.CONFLICT)
	                                 .body("Username already exists");
	        }
	
	        User user = new User();
	        user.setUsername(dto.getUsername());
	        user.setPassword(dto.getPassword()); // можно хэшировать потом
	        user.setName(dto.getName());
	        user.setSurname(dto.getSurname());
	        user.setEmail(dto.getEmail());
	
	        userRepository.save(user);
	        return ResponseEntity.status(HttpStatus.CREATED).body(user);
	    }
	
	    // LOGIN → 200 + JWT
	    @PostMapping("/login")
	    public ResponseEntity<?> login(@RequestBody LoginRequestDto dto) {
	        Optional<User> userOpt = userRepository.findByUsername(dto.getUsername());

	        if (userOpt.isEmpty() || !userOpt.get().getPassword().equals(dto.getPassword())) {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
	                                 .body(Map.of("message", "The username or password that you entered is incorrect"));
	        }

	        String token = jwtUtil.generateToken(userOpt.get().getUsername());
	        Map<String, String> map = new HashMap<>();
	        map.put("token", token);
	        return ResponseEntity.ok(map);
	    }

	    
	    @GetMapping("/me")
	    public ResponseEntity<?> userMe(Principal principal) {
	        if (principal == null) {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
	                                 .body("You are not logged in");
	        }
	
	        User user = userRepository.findByUsername(principal.getName())
	                                  .orElseThrow(() -> 
	                                      new UsernameNotFoundException("User not found"));
	
	        return ResponseEntity.ok(user);
	    }
	}
	
	
	
