package productshop.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
@NoArgsConstructor
@Data
@AllArgsConstructor
public class ProductDto {
	private long id;
    @NotBlank(message = "There should be imageUrl of your product!")
    private String imageUrl;
	private long OwnerId;
	private String name;
	@NotBlank(message = "Brand is a must to include!")
	@Size(min = 2, max = 50, message = "Brand length must be between 2 and 50!")
	private String brand;

	public long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getOwnerId() {
		return OwnerId;
	}

	public void setOwnerId(long ownerId) {
		OwnerId = ownerId;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@NotBlank(message = "You must enter ther category of the product!")
	private String category;
	private String size;
	@NotBlank(message = "You should enter the color of your product!")
	private String color;
	private String material;
	private Double price;
	private Integer quantity;
	@Min(value = 1, message = "Minimum rating value is 1!")
	@Max(value = 5, message = "Maximum rating value is 5!")
	private Integer rating;
	@Size(max = 500, message = "Description length must be maximum 500!")
	private String description;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    public String getImageUrl() {
        return imageUrl;
    }
}


