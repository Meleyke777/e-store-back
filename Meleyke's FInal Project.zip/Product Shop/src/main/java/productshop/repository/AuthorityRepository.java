package productshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import productshop.entity.Authority;

public interface AuthorityRepository extends JpaRepository<Authority, Long> {
    // no need to declare save(), JpaRepository already has it
}
