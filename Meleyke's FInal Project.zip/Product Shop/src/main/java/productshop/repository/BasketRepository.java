package productshop.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import productshop.entity.Basket;

public interface BasketRepository extends JpaRepository<Basket, Long> {

    List<Basket> findByUserId(Long userId);

    Optional<Basket> findByUserIdAndProductId(Long userId, Long productId);

    void deleteByUserIdAndProductId(Long userId, Long productId);
}

