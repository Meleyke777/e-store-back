package productshop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import productshop.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByRating(Integer rating);

    List<Product> findByBrandContainingIgnoreCase(String keyword);
    List<Product> findAllByOrderByPriceAsc();

    List<Product> findAllByOrderByPriceDesc();

    List<Product> findByCategory(String category);

	List<Product> findByOwnerId(Long id);
}
