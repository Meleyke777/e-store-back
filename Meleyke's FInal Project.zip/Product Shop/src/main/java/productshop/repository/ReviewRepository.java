package productshop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import productshop.entity.Review;

public interface ReviewRepository extends JpaRepository<Review, Long> {

	List<ReviewRepository> findByProductId(Long productId);
    // you don’t need to redefine save() — JpaRepository already has it

}