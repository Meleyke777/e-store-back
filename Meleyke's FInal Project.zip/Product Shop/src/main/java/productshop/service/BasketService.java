
package productshop.service;

import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import productshop.dto.BasketProductResponseDto;
import productshop.entity.Basket;
import productshop.entity.Product;
import productshop.entity.User;
import productshop.repository.BasketRepository;
import productshop.repository.ProductRepository;
import productshop.repository.UserRepository;

@Service
public class BasketService {

    private final BasketRepository basketRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public BasketService(BasketRepository basketRepository,
                         ProductRepository productRepository,
                         UserRepository userRepository) {
        this.basketRepository = basketRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    private User getCurrentUser() {
        String username = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

    }

    public void addToBasket(Long productId) {
        User user = getCurrentUser();

        productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("product not found"));

        Basket basket = basketRepository
                .findByUserIdAndProductId(user.getId(), productId)
                .orElse(null);

        if (basket == null) {
            Basket newBasket = new Basket();
            newBasket.setUserId(user.getId());
            newBasket.setProductId(productId);
            newBasket.setQuantity(1);
            basketRepository.save(newBasket);
        } else {
            basket.setQuantity(basket.getQuantity() + 1);
            basketRepository.save(basket);
        }
    }

    public List<BasketProductResponseDto> myBaskets() {
        User user = getCurrentUser();

        List<Basket> baskets = basketRepository.findByUserId(user.getId());

        return baskets.stream().map(basket -> {
            Product product = productRepository.findById(basket.getProductId())
                    .orElseThrow(() -> new RuntimeException("product not found"));

            BasketProductResponseDto dto = new BasketProductResponseDto();
            dto.setBasketId(basket.getId());
            dto.setProductId(product.getId());
            dto.setName(product.getName());
            dto.setPrice(product.getPrice());
            dto.setImgUrl(product.getImageUrl());
            dto.setQuantity(basket.getQuantity());
            return dto;
        }).toList();
    }

    public void removeFromBasket(Long productId) {
        User user = getCurrentUser();

        Basket basket = basketRepository
                .findByUserIdAndProductId(user.getId(), productId)
                .orElseThrow(() -> new RuntimeException("basket not found"));

        basketRepository.delete(basket);
    }
}		
