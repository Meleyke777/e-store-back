package productshop.service;

import java.util.List;

import org.springframework.stereotype.Service;

import productshop.dto.ProductDto;
import productshop.entity.Product;
import productshop.repository.ProductRepository;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAll() {
        return productRepository.findAll();
    }

    public Product getById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public List<Product> getByRating(Integer rating) {
        return productRepository.findByRating(rating);
    }

    public List<Product> searchByBrand(String keyword) {
        return productRepository.findByBrandContainingIgnoreCase(keyword);
    }

    public List<Product> getPriceAsc() {
        return productRepository.findAllByOrderByPriceAsc();
    }

    public List<Product> getPriceDesc() {
        return productRepository.findAllByOrderByPriceDesc();
    }

    public List<Product> getByCategory(String category) {
        return productRepository.findByCategory(category);
    }
}
