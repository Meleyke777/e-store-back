package productshop.service;

import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import productshop.dto.ReviewDto;
import productshop.entity.Review;
import productshop.entity.User;
import productshop.repository.ProductRepository;
import productshop.repository.ReviewRepository;
import productshop.repository.UserRepository;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    public ReviewService(ReviewRepository reviewRepository,
                         UserRepository userRepository,
                         ProductRepository productRepository) {
        this.reviewRepository = reviewRepository;
        this.userRepository = userRepository;
        this.productRepository = productRepository;
    }

    // Create a new review for a product
    public Review create(ReviewDto reviewDto) {
        User user = getCurrentUser();

        // Check product exists
        productRepository.findById(reviewDto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Review review = new Review();
        review.setProductId(reviewDto.getProductId()); // renamed from clothId
        review.setComment(reviewDto.getComment());
        review.setUserId(user.getId());
        review.setRating(reviewDto.getRating());

        return reviewRepository.save(review);
    }

    // Get all reviews for a specific product
    public List<ReviewRepository> getByProduct(Long productId) {
        return reviewRepository.findByProductId(productId); // renamed method
    }

    // Delete a review
    public void delete(Long id) {
        Review review = reviewRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Review not found"));

        User user = getCurrentUser();

        if (!review.getUserId().equals(user.getId())) {
            throw new RuntimeException("You are not allowed to delete this review");
        }

        reviewRepository.deleteById(id);
    }

    // Helper method to get currently authenticated user
    private User getCurrentUser() {
        String username = SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();

        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

    }
}
