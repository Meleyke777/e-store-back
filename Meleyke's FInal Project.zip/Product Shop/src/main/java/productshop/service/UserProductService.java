package productshop.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import productshop.dto.ProductDto;
import productshop.entity.Product;
import productshop.entity.User;
import productshop.repository.ProductRepository;
import productshop.repository.UserRepository;

@Service
public class UserProductService {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public UserProductService(ProductRepository productRepository,
                              UserRepository userRepository) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    public ProductDto saveProduct(ProductDto dto) {
        User currentUser = getCurrentUser();
        Product product = new Product();
        copyDtoToProduct(dto, product);
        product.setOwnerId(currentUser.getId());

        Product savedProduct = productRepository.save(product);
        return convertToDto(savedProduct);
    }

    public ProductDto updateProduct(Long id, ProductDto dto) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User currentUser = getCurrentUser();
        if (!product.getOwnerId().equals(currentUser.getId())) {
            throw new RuntimeException("Unauthorized");
        }

        copyDtoToProduct(dto, product);
        Product updatedProduct = productRepository.save(product);
        return convertToDto(updatedProduct);
    }

    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User currentUser = getCurrentUser();
        if (!product.getOwnerId().equals(currentUser.getId())) {
            throw new RuntimeException("Unauthorized");
        }
        productRepository.delete(product);
    }

    public List<ProductDto> getMyProducts() {
        User currentUser = getCurrentUser();
        return productRepository.findByOwnerId(currentUser.getId())
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private User getCurrentUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }


    // Transfers data from Request (DTO) -> Database (Entity)
    private void copyDtoToProduct(ProductDto dto, Product product) {
        product.setName(dto.getName());
        product.setBrand(dto.getBrand());
        product.setCategory(dto.getCategory());
        product.setSize(dto.getSize());
        product.setColor(dto.getColor());
        product.setMaterial(dto.getMaterial());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setImageUrl(dto.getImageUrl());
        product.setRating(dto.getRating());
        product.setDescription(dto.getDescription());
    }

    // ✅ FULLY FINISHED: Transfers data from Database (Entity) -> Response (DTO)
    private ProductDto convertToDto(Product product) {
        ProductDto dto = new ProductDto();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setBrand(product.getBrand());
        dto.setCategory(product.getCategory());
        dto.setSize(product.getSize());
        dto.setColor(product.getColor());
        dto.setMaterial(product.getMaterial());
        dto.setPrice(product.getPrice());
        dto.setQuantity(product.getQuantity());
        dto.setImageUrl(product.getImageUrl());
        dto.setRating(product.getRating());
        dto.setDescription(product.getDescription());
        dto.setOwnerId(product.getOwnerId()); 
        return dto;
    }
}