package productshop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import productshop.dto.RegisterRequestDto;
import productshop.dto.UserMeDto;
import productshop.entity.User;
import productshop.jwt.JWTUtil;
import productshop.repository.UserRepository;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    public UserService(UserRepository userRepository) { this.userRepository = userRepository; }

    public User register(RegisterRequestDto dto) {
        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(dto.getPassword()); // Для реального проекта хэшировать пароль
        user.setName(dto.getName());
        user.setSurname(dto.getSurname());
        user.setEmail(dto.getEmail());
        return userRepository.save(user);
    }

    public String login(String username, String password) throws Exception {
    	Optional<User> userOpt = userRepository.findByUsername(username);

        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            return "FAKE-TOKEN-FOR-TEST"; // Для теста
        } else {
            throw new Exception("Invalid credentials");
        }
    }


	// UserService.java
	public Optional<User> findByUsername(String username) {
		return userRepository.findByUsername(username);
 // JPA возвращает Optional, не null
	}
	@Autowired
	private JWTUtil jwtUtil;

	public String login(User user) {
	    // Генерируем настоящий JWT
	    return jwtUtil.generateToken(user.getUsername());
	}


	public UserMeDto me() {
		// TODO Auto-generated method stub
		return null;
	}
}
